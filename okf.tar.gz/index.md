---
okf_version: "0.1"
title: "J.R. Cruciani · impermanente · OKF"
description: "Archivo OKF clonable de J.R. Cruciani: fotografía (bundle visual) y notas públicas del blog."
---

# J.R. Cruciani · OKF

Bundle Open Knowledge Format v0.1 de J.R. Cruciani — fotógrafo y escritor.

## Proyecto

*impermanente* reúne fotografías y textos sobre los umbrales y los cambios. El nombre adapta *mujō* (無常), el término budista japonés para el hecho de que nada permanece: es el tema. *Mono no aware* (物の哀れ), la emoción ante lo efímero, es el tono. Más contexto en [Acerca de](https://impermanente.es/acerca/).

## Fotografía

La obra fotográfica es la faceta creativa principal. El archivo visual vive en su propio bundle OKF:

* [Galería](https://impermanente.es/fotos/) - fotografía de umbrales, calle, ciudades y luz dorada.

## Escritura — notas del blog

* [Blog original](https://impermanente.es/blog/) - fuente canónica de las notas
* [llms.txt del blog](https://impermanente.es/llms.txt) - índice para LLMs
* [Tarball](/okf.tar.gz) - descarga clonable del bundle

## Notas

### 2026

* [Still Blue, mi segunda receta Fujifilm](/notas/2026-09-27-still-blue.md) - Still Blue es la receta opuesta a Valeria Blue .
* [Apropiación ideológica](/notas/2026-09-27-apropiacion-ideologica.md) - Empiezo con un videojuego, pero tengan paciencia ya que el punto al que quiero llegar es serio.
* [Porque podemos](/notas/2026-09-25-porque-podemos.md) - Veo muchas personas, lamentablemente, que piensan votar a partidos que saben perfectamente que no van a beneficiar a la mayoría, pero que sí los van a beneficiar a ellos.
* [Parecer que sabes](/notas/2026-09-13-parecer-que-sabes.md) - Ayer un grupo de jóvenes me explicaron lo que es un LARP.
* [Yo pensaba que estábamos de acuerdo](/notas/2026-09-08-yo-pensaba-que-estabamos-de-acuerdo.md) - Cuando era joven me consideraba de derecha, pues la verdad es que el capitalismo me parecía un modelo real, que funcionaba, mientras que la izquierda que me llegaba hablaba de propiedad colectiva, de salarios, de cosas q
* [Mi primera receta Fujifilm](/notas/2026-08-30-valeria-blue.md) - Valeria Blue es la primera receta Fujifilm que hago desde cero y también la primera que comparto.
* [La perfección se devaluó](/notas/2026-08-26-la-perfeccion-se-devaluo.md) - Me he dado cuenta de que cuando escribo sobre fotografía casi siempre es para quejarme… pero es que tengo razón… jajajaja.
* [El Mundo Invisible queda abierto](/notas/2026-08-23-el-mundo-invisible-queda-abierto.md) - Escribir Hispania Obscura me tomó dos años, pero las ideas que terminaron dentro me tomaron más de diez.
* [Hemos domesticado el rayo](/notas/2026-08-11-hemos-domesticado-el-rayo.md) - Somos dioses. O al menos, para alguien de la era victoriana, podríamos parecerlo.
* [El reencuadre manipulativo](/notas/2026-08-03-el-reencuadre-manipulativo.md) - Hay una maniobra retórica que lamentablemente ya veo en uso todos los días y cuyo nombre en inglés no se traduce bien, así que le voy a poner yo uno: el reencuadre manipulativo.
* [Cómo Enki llegó a la península por la esquina del mapa](/notas/2026-07-26-cmo-enki-lleg-a-la.md) - Imaginen esto: los dioses han decidido acabar con la humanidad porque hacen demasiado ruido (literalmente, no dejan dormir a Enlil).
* [Incendios forestales](/notas/2026-07-26-incendios-forestales.md) - Este blog no suele ir de estos temas, pero cada verano vuelve la misma conversación y casi siempre con las mismas ideas equivocadas.
* [Sobre la polarización](/notas/2026-07-05-sobre-la-polarizacin.md) - Últimamente todas las conversaciones, en redes y en persona, se sienten algo así: Sujeto 1: Ir muy lento en la autopista puede provocar accidentes, se debería ir lo mas rápido posible siempre.
* [El espejo tiene acento](/notas/2026-07-04-el-espejo-tiene-acento.md) - Hace un par de meses escribí que un chatbot era un espejo sin centro y que cuando uno busca al que mira detrás de los ojos, no lo encuentra, ya que el espejo no te devuelve una imagen sino tu propio yo.
* [Fuera de la caja... hay otra caja](/notas/2026-06-28-fuera-de-la-caja-hay.md) - Leor Zmigrod, que ha escrito un libro titulado The Ideological Brain , lleva años midiendo algo que en apariencia no tiene nada que ver con la política: la rigidez cognitiva.
* [El último deseo](/notas/2026-06-19-el-ltimo-deseo.md) - Cualquiera que haya leído a Sapkowski o jugado lo suficiente a Dungeons & Dragons conoce el chiste, y conoce el miedo que hay debajo del chiste.
* [El veterano de la empresa](/notas/2026-06-14-el-veterano-de-la-empresa.md) - El día de hoy Satya Nadella, CEO de Microsoft, publicó un texto en su blog que titula "A frontier without an ecosystem is not stable" y ahí habla sobre cómo imagina a su empresa en una economía movida por la IA.
* [La gramática de los dioses](/notas/2026-05-31-la-gramtica-de-los-dioses.md) - Hace unos meses escribí que clasificar a los dioses por dominios es un error de colegio: Ares el de la guerra, Poseidón el de los mares, y ya está.
* [Quis custodiet ipsos custodes?](/notas/2026-05-31-quis-custodiet-ipsos-custodes.md) - Esto no lo escribo desde la teoría. Llevo meses con las manos metidas en dos experimentos que son, cada uno a su manera, una respuesta a un mismo problema.
* [Seguimos compartiendo el producto, no la idea](/notas/2026-05-25-seguimos-compartiendo-el-producto-no.md) - Hace unas semanas escribí que la herramienta perfecta para otro no se compra ni se descarga: se reescribe.
* [El nombre es el mensaje](/notas/2026-05-18-el-nombre-es-el-mensaje.md) - No soy católico a pesar de (o tal vez gracias a) que estudié en un colegio católico.
* [Anatta a la inversa](/notas/2026-05-10-anatta-a-la-inversa.md) - Hay una palabra que se usa en budismo, anatta , que se traduce mal casi siempre.
* [La Jihad no era contra las máquinas](/notas/2026-05-07-la-jihad-no-era-contra.md) - La frase aparece pronto en Dune : “no harás una máquina a semejanza de la mente humana”.
* [Una máquina propia para una web pequeña](/notas/2026-05-05-una-mquina-propia-para-una.md) - Siempre me hizo gracia que en Shadowrun y Cyberpunk el ordenador no fuera invisible.
* [El mito personal](/notas/2026-05-04-el-mito-personal.md) - Hace unos días leí un artículo en Existential Espresso sobre la necesidad de tener un mito personal en la era de la IA.
* [Feeds recomendados](/notas/2026-04-30-feeds-recomendados.md) - En un mundo donde los AIs generan millones de posts por segundo para bombardearnos con ruido sobre todos los temas, y hasta intentar manipularnos, siempre es refrescante tener algunas fuentes de temas curados e interesan
* [El mini-culto de uno](/notas/2026-04-21-el-miniculto-de-uno.md) - Hace unos días un amigo me contactó con la clásica de “tengo que contarte algo importante”.
* [El fin del "one size fits all"](/notas/2026-04-18-el-fin-del-one-size.md) - Durante décadas trabajamos bajo un modelo implícito que podríamos llamar el modelo SAP: existe una forma “correcta” de hacer las cosas, alguien la ha codificado en una herramienta, y tu trabajo consiste en adaptar tus pr
* [Blog rediseñado](/notas/2026-04-06-blog-rediseado.md) - Y bueno, eso… aunque si me lees en RSS (y te felicito por eso) no lo vas a notar.
* [Aquí tampoco es](/notas/2026-04-01-aqu-tampoco-es.md) - Por temas de trabajo he tenido la suerte de poder viajar mucho, desde muy joven.
* [Ozymandias](/notas/2026-04-01-ozymandias.md) - I met a traveller from an antique land, Who said—“Two vast and trunkless legs of stone Stand in the desert.
* [Rojo](/notas/2026-03-30-rojo.md) - Rojo
* [Annica](/notas/2026-03-26-annica.md) - Obtuve acceso a un AI con recursos, para fines prácticos, ilimitados.
* [Por ahí no es](/notas/2026-03-25-por-ah-no-es.md) - Hay un verso de Shelley que es el favorito de mi hijo mayor.
* [Los nueve juegos...](/notas/2026-03-10-los-nueve-juegos.md) - …que definieron mi infancia, de acuerdo al último trend de moda en redes =)
* [Una sociedad a prueba de fuegos](/notas/2026-03-04-una-sociedad-a-prueba-de.md) - Hace unos meses escribí sobre cómo el capitalismo no está roto , sino que hace exactamente lo que sabe hacer (POSIWID).
* [Soberanía digital personal](/notas/2026-02-28-soberana-digital-personal.md) - ¿Quién decide si voy a poder abrir mis documentos actuales en diez años?
* [Sobre el por qué tomo fotografías](/notas/2026-02-18-sobre-el-por-qu-tomo.md) - Hay algo que me cuesta admitir, aunque tampoco tengo ya demasiados reparos en decirlo: no recuerdo casi nada de mi infancia.
* [Un poco de humildad](/notas/2026-01-30-un-poco-de-humildad.md) - Carl Sagan tenía una habilidad increíble para recordarnos lo pequeños que somos sin que sonara pedante.
* [La calle](/notas/2026-01-12-la-calle.md) - La calle

### 2025

* [Herramientas más usadas el 2025](/notas/2025-12-29-herramientas-ms-usadas-el.md) - Todos los años solía hacer un post de este tipo con las herramientas de tecnología que más había usado.
* [Basta con lo cinematográfico](/notas/2025-12-10-basta-con-lo-cinematogrfico.md) - Hace unos días asisti a una exposición audiovisual muy interesante sobre el Valle del Cauca en Colombia, donde quedé impresionado por la historia que los artistas contaban desde diversos ángulos: religioso, mítico, dramá
* [Sobre dioses mitológicos](/notas/2025-11-25-sobre-dioses-mitologcos.md) - A medida que investigo más cosas para mi siguiente libro, me voy dando cuenta de lo mal que me enseñaron sobre mitologia en el colegio… además de que luego ve uno repetidos los mismos errores en otros lados.
* [Una nueva era](/notas/2025-11-11-una-nueva-era.md) - Una nueva era
* [Pasó en la península](/notas/2025-11-09-pas-en-la-pennsula.md) - Yo crecí con la ficción de Asterix y Obelix, pero la historia real de una aldea celta resistiendo a los romanos por años se dió en Numancia.
* [Esperando a la Alpha 7 V](/notas/2025-11-01-esperando-a-la-alpha-v.md) - La Sony Alpha 7 II, aunque sigue tomando fotos espectaculares, ya tiene muchas carencias que los modelos más modernos incluyen.
* [Pensamiento de blog #3](/notas/2025-10-30-pensamiento-de-blog.md) - El enorme éxito del método científico en los últimos cientos de años nos ha llevado a pensar que todo lo que existe debe ser físico y medible.
* [La máquina no está rota](/notas/2025-10-29-la-mquina-no-est-rota.md) - En ingeniería de sistemas existe un concepto llamado POSIWID, que son las siglas en inglés de “the purpose of a system is what it does”.
* [Pensamiento de blog #2](/notas/2025-10-29-pensamiento-de-blog.md) - Vivimos en un mundo donde todos corren muy rápido porque quieren llegar al futuro antes que nadie.
* [Pensamiento de blog #1](/notas/2025-10-19-pensamiento-de-blog.md) - Muchos les dirán que deben definir objetivos claros y específicos para su vida.
* [El hacker atemporal](/notas/2025-10-15-el-hacker-atemporal.md) - El otro día, mientras revisaba unos libros viejos de mi biblioteca, me encontré con Hackers: Heroes of the Computer Revolution de Steven Levy.
* [Las noticias, más lento](/notas/2025-10-14-las-noticias-ms-lento.md) - Como parte de mi proceso de dejar todas las redes que no son del Fediverso, y de la mano con mi recientemente actualizada y curada lista de feeds RSS, me bajé el app de Kagi News.
* [Street Art](/notas/2025-10-09-street-art.md) - Street Art
* [Hablemos de migración](/notas/2025-10-09-hablemos-de-migracin.md) - Me ha costado mucho últimamente defender una frase tan sencilla como “La inmigración es buena para la economía” en mi círculo de conocidos.
* [Cómo convencí a dos amigos de cambiar su voto.](/notas/2025-10-06-cmo-convenc-a-dos-amigos.md) - Algo que es importante recordar es que la mayoría de las personas que hoy piensan en votar a la extrema derecha no lo hacen porque sean, en esencia, de extrema derecha.
* [Computational Photography](/notas/2025-10-04-computational-photography.md) - Madrid, antes de las manifestaciones
* [Street wisdom](/notas/2025-09-22-street-wisdom.md) - Street wisdom
* [Lavapiés](/notas/2025-09-22-lavapies.md) - Lavapiés
* [Es imposible ser de centro hoy](/notas/2025-09-16-es-imposible-ser-de-centro.md) - Hoy en día todo está politizado, polarizado, todo es una declaración.
* [Brihuega](/notas/2025-09-15-brihuega.md) - Brihuega
* [Albi](/notas/2025-09-02-albi.md) - Albi
* [Ángeles en los jardines del Vaticano](/notas/2025-08-26-no-s-ustedes-pero-a.md) - No sé ustedes, pero a mí me parece que esta obra los jardines del Vaticano es la representación más cercana a las descripciones que hay de los ángeles en su biblia
* [Herensuge](/notas/2025-08-24-herensuge.md) - He publicado un capítulo del que será el segundo libro de la serie de fantasía urbana, Herensuge, para acceso gratuito.
* [Napoli](/notas/2025-08-22-milano.md) - Napoli
* [Roma](/notas/2025-08-19-roma.md) - Roma
* [Vatican City](/notas/2025-08-18-vatican-city.md) - Vatican City
* [Ciao Roma](/notas/2025-08-16-ciao-roma.md) - Ciao Roma
* [Necropolítica](/notas/2025-08-15-necropoltica.md) - Según Wikipedia , la necropolítica es un concepto que hace referencia al uso del poder social y político para dictar cómo algunas personas pueden vivir y cómo algunas deben morir.
* [Tratando de retomar el control](/notas/2025-08-13-tratando-de-retomar-el-control.md) - En los últimos meses he iniciado una serie de cambios en la manera en que interactúo con la tecnología.
* [Qué uso](/notas/2025-08-12-qu-uso.md) - A raíz de haber migrado el blog, las fotos y los links a mis libros a esta nueva plataforma, creo que vale la pena actualizar el post de qué tecnologías y servicios uso, pues el 2025 si que trajo novedades.
* [Catedral ortodoxa en Niza](/notas/2025-08-12-catedral-ortodoxa-en-niza.md) - Catedral Ortodoxa en Niza
* [Nuevo reloj, nueva plataforma para el blog](/notas/2025-08-11-nuevo-reloj-nueva-plataforma-para.md) - Nuevo reloj, nueva plataforma para el blog….
* [Cyberpunk, pero sin neón](/notas/2025-08-11-cyberpunk-pero-sin-nen.md) - Cuando yo era un joven aficionado a los juegos de rol, existía uno llamado Cyberpunk 2020.
* [El mundo necesita más Carl Sagan](/notas/2025-08-11-el-mundo-necesita-ms-carl.md) - Hace poco me encontraba pensando en por qué ciertos mensajes, aunque sean fundamentalmente correctos o importantes, generan tanto rechazo en la sociedad.
* [El futuro esta detrás de nosotros](/notas/2025-08-11-el-futuro-esta-detrs-de.md) - Hace unos días, mientras investigaba para mi próximo libro, me topé con un concepto lingüístico que me voló la cabeza: En el idioma aymara, hablado en Bolivia, Perú y Chile, el pasado está adelante y el futuro está atrás

### 2024

* [El futuro es de los editores](/notas/2024-07-18-el-futuro-es-de-los.md) - Hace poco vi un deepfake de AI con el entrenador del equipo de fútbol de Inglaterra insultando a sus jugadores.
* [Neo-Oscurantismo](/notas/2024-07-11-neooscurantismo.md) - Hoy en día, hay una definición aceptada de snob: one who has an offensive air of superiority in matters of knowledge or taste.
* [Advertencia, esta es una historia de privilegio.](/notas/2024-06-02-advertencia-esta-es-una-historia.md) - Hace unas semanas me encontraba contando una historia a un grupo de estudiantes universitarios de Uruguay.

### 2023

* [Subiendo mis fotos a la nueva plataforma](/notas/2023-10-15-lugares-de-descanso.md) - Las fotos de este post viven ahora en fotos.impermanente.es .

