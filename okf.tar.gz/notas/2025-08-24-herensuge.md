---
type: "Entrada"
title: "Herensuge"
description: "He publicado un capítulo del que será el segundo libro de la serie de fantasía urbana, Herensuge, para acceso gratuito."
resource: "https://impermanente.es/blog/2025/08/24/herensuge/"
tags: ["Escritura"]
timestamp: "2025-08-24T14:06:12+02:00"
---

He publicado un capítulo del que será el segundo libro de la serie de fantasía urbana, Herensuge, para acceso gratuito.
No tiene spoilers para el primer libro, pero obviamente se disfruta mejor si ya leyeron Hispania Obscura.

[impermanente.es/hispania-…](/hispania-obscura/)

# Citations

[1] [Original en el blog](https://impermanente.es/blog/2025/08/24/herensuge/)
