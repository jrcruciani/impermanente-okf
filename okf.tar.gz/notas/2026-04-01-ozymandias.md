---
type: "Entrada"
title: "Ozymandias"
description: "I met a traveller from an antique land, Who said—“Two vast and trunkless legs of stone Stand in the desert."
resource: "https://impermanente.es/blog/2026/04/01/ozymandias/"
tags: ["Filosofia"]
timestamp: "2026-04-01T20:49:09+02:00"
---

I met a traveller from an antique land,
Who said—“Two vast and trunkless legs of stone
Stand in the desert. . . . Near them, on the sand,
Half sunk a shattered visage lies, whose frown,
And wrinkled lip, and sneer of cold command,
Tell that its sculptor well those passions read
Which yet survive, stamped on these lifeless things,
The hand that mocked them, and the heart that fed;
And on the pedestal, these words appear:
My name is Ozymandias, King of Kings;
Look on my Works, ye Mighty, and despair!"
Nothing beside remains. Round the decay
Of that colossal Wreck, boundless and bare
The lone and level sands stretch far away.

# Citations

[1] [Original en el blog](https://impermanente.es/blog/2026/04/01/ozymandias/)
